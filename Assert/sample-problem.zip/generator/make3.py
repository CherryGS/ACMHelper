from random import choice

print(choice([1, -1]))
