#include <bits/stdc++.h>
using namespace std;

int main() {
    int a; 
    cin >> a; 
    cout << abs(a)/2 << '\n'; 
    return 0;
}