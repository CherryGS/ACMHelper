#include <bits/stdc++.h>
using namespace std;

int main() {
    int a; 
    cin >> a; 
    if(a >= 0) { cout << a-1 << '\n'; }
    else { cout << a+1 << '\n'; }
    return 0;
}