#include <bits/stdc++.h>
#include "testlib.h"
std::mt19937 rng(std::random_device{}());
using namespace std;

/*
    inf : input
    ouf : user output
    ans : answer output

    _ok : Accept
    _wa : Wrong Answer
    _fail : System failed
    _pe : Presentation Error
*/

int main(int argc,char** argv) {
    registerTestlibCmd(argc,argv); // Required
    
    int n = inf.readInt();
    int m = ouf.readInt();
    if(rng()%4 == 0) { quitf(_fail, "Test failed error."); }

    if(abs(m) < abs(n)) { quitf(_ok,"Correct!"); }
    else { quitf(_wa,"Wrong Answer!"); }
}