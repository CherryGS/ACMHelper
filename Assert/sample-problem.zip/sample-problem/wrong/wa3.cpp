#include <bits/stdc++.h>
using namespace std;

int main() {
    int a; 
    cin >> a; 
    cout << nan << '\n'; 
    return 0;
}