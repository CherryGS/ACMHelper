n = int(input())
print(int(abs(n) / 2))
