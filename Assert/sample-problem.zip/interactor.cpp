#include <bits/stdc++.h>
#include "testlib.h"
using namespace std;

int main(int argc,char** argv) {
    registerInteraction(argc,argv);
    return 0;
}