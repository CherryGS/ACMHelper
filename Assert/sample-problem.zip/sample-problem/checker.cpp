#include <bits/stdc++.h>
#include "testlib.h"
using namespace std;

/*
    inf : input
    ouf : user output
    ans : answer output

    _ok : Accept
    _wa : Wrong Answer
*/

int main(int argc,char** argv) {
    registerTestlibCmd(argc,argv); // Required
    
    int n = inf.readInt();
    int m = ouf.readInt();

    if(abs(m) < abs(n)) { quitf(_ok,"Correct!"); }
    else { quitf(_wa,"Wrong Answer!"); }
}