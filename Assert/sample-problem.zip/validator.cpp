#include <bits/stdc++.h>
#include "testlib.h"
using namespace std;

int main(int argc,char** argv) {
    registerValidation(argc,argv);
    inf.readEof();
    return 0;
}